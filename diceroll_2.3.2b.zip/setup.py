#
# At the CMD prompt type:
#
# setup.py install
# or
# python setup.py install
#

from game_utils.diceroll import __release__

try:
    from setuptools import setup
except ImportError:
    from distutils.core import setup

setup(
    name='diceroll',
    version=__release__,
    author='Shawn Driscoll',
    author_email='shawndriscoll@hotmail.com',
    packages=['game_utils'],
    scripts=[],
    url='https://diceroll.readthedocs.io/en/latest/',
    description='A classic RPG dice rolling tool for Python 2.5.',
    long_description=open('README.rst').read(),
    platforms=['Win32'],
    classifiers=[
        'Topic :: Games/Entertainment',
        'Programming Language :: Python :: 2.5',
        'Programming Language :: Python :: Implementation :: CPython',
        'Operating System :: Microsoft :: Windows :: Windows XP',
        'Operating System :: Microsoft :: Windows :: Windows 7',
        'Operating System :: Microsoft :: Windows :: Windows 10',
    ],
    license='game_utils and diceroll 2.3 are not for commercial use.'
)