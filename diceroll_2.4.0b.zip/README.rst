**diceroll 2.4 for Python 2.5**
===============================

.. figure:: images/diceroll_manual_cover_art.png

**diceroll 2.4** is a Python 2.5 module that your game code calls to make dice rolls.

Read the **diceroll Operations Manual** at http://diceroll.readthedocs.io

Download the PDF from https://readthedocs.org/projects/diceroll/downloads/pdf/latest

or the EPUB from https://readthedocs.org/projects/diceroll/downloads/epub/latest
